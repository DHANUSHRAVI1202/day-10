import React from "react";
function SubmittedForm() {
    return (
      <div>
        <h2>Submitted Form</h2>
        <p>Thank you for submitting your form!</p>
      </div>
    );
  }
  export default SubmittedForm;