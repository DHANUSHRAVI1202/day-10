import React from "react";
function Contact() {
    return (
      <div>
        <center><h2>Contact</h2>
        <p>Get in touch with us!</p></center>
      </div>
    );
  }
  export default Contact;