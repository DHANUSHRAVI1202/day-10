import React from "react";
function Home() {
    return (
      <div>
        <center><h2>Home</h2>
        <p>Welcome to our travel website!</p></center>
      </div>
    );
  }
  export default Home;