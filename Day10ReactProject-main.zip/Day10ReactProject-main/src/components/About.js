import React from "react";
function About() {
    return (
      <div>
        <center><h2>About</h2>
        <p>Learn more about our company and mission.</p></center>
      </div>
    );
  }
  export default About;