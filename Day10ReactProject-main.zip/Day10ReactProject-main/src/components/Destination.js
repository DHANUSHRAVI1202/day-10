import React from "react";
function Destination() {
    return (
      <div>
        <center><h2>Destination</h2>
        <p>Check out some of our popular destinations!</p></center>
      </div>
    );
  }
  export default Destination;